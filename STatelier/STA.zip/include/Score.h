#pragma once

namespace STatelier::Score
{
	class Score
	{

	};
}