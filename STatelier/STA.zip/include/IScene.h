#pragma once

#include <cstdint>
#include <coroutine>
#include <experimental/generator>

#include <SelectItemControl.h>

using namespace STatelier::SongSelect;

namespace STatelier
{
	class IScene
	{
	public:
		virtual int32_t PreStart() = 0;
		virtual std::experimental::generator<int> GetStartIterator() = 0;
	private:
	};

	class SongSelectScene : public IScene
	{
	public:
		virtual int32_t PreStart() override
		{
			auto selectItemControl = new SelectItemControl();

			selectItemControl->Load("R:\\C#\\Tatelier\\Tatelier\\bin\\x64\\Debug\\Resources\\Score\\Root");

			return 0;
		}
		virtual std::experimental::generator<int> GetStartIterator() override
		{
			co_yield 0;
			co_return;
		};
	};
}