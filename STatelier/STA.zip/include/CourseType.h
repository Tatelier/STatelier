#pragma once

namespace STatelier::Score
{
	enum class CourseType
	{
		Easy,
		Normal,
		Hard,
		VeryHardA,
		VeryHardB,
	};
}