#pragma once

#include <string>

namespace STatelier
{
	class MainConfig
	{
	public:
		MainConfig(const std::string& filePath);
	};
}