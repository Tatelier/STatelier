#include "SceneControl.h"

namespace STatelier
{
	void SceneControl::Start()
	{
		auto scene = CreateScene<SongSelectScene>();
		scene->PreStart();
	}

	void SceneControl::Update()
	{
	}
	void SceneControl::Draw()
	{
	}
	void SceneControl::Finish()
	{
	}

	template <typename T> 
	T* SceneControl::CreateScene()
	{
		auto a = new T();
		m_pSceneList.push_back(a);

		return a;
	}

}