#include "MainConfig.h"


namespace STatelier
{
	MainConfig::MainConfig(const std::string& filePath)
	{

	}
}