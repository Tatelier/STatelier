#include "IScene.h"

namespace STatelier
{
	int32_t IScene::PreStart()
	{
		return 0;
	}
}